var gulp       = require('gulp');
var babel = require("gulp-babel");
// var livereload = require('gulp-livereload'); // 网页自动刷新（服务器控制客户端同步刷新）
var proxyMiddleware = require('http-proxy-middleware');
var browserSync = require('browser-sync');


// 注册任务
gulp.task('reload',['babel'], browserSync.reload);
gulp.task("babel", function () {
  return gulp.src(["app/scripts/**/*.js"])// ES6 源码存放的路径
    .pipe(babel()) 
    .pipe(gulp.dest("dist/scripts/")); //转换成 ES5 存放的路径
});
gulp.task('browserSync', function() {
    // 代理配置, 实现环境切换
    var middleware = proxyMiddleware(['/masking', '/LocalFile'], {target: "http://192.168.112.51", changeOrigin: true});
    // var middleware = proxyMiddleware(['/api'], {target: "http://localhost:8888", changeOrigin: true});
    browserSync({
        server: {
            baseDir: './app',
            // middleware: middleware,
            index: 'index.html'
        },
        port: 3512
    });

    gulp.watch('app/scripts_map/**/*.js',['reload']);
    // gulp.watch('access/scripts/**/*.js', browserSync.reload);
    gulp.watch('app/**/*.html',browserSync.reload);
    gulp.watch('app/**/*.css',browserSync.reload);
    gulp.watch('app/**/*.json',browserSync.reload);
});
// 默认任务
gulp.task('default',['babel', 'browserSync']);