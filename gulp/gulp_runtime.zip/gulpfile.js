var gulp       = require('gulp');
var babel = require("gulp-babel");
var proxyMiddleware = require('http-proxy-middleware');
var browserSync = require('browser-sync');

// 注册任务
gulp.task('reload',['babel'], browserSync.reload);
gulp.task("babel", function () {
  return gulp.src(["access/scripts_map/app/collection/**/*.js"])// ES6 源码存放的路径
    .pipe(babel()) 
    .pipe(gulp.dest("access/scripts/app/collection/")); //转换成 ES5 存放的路径
});
gulp.task('browserSync', function() {
    // 代理配置, 实现环境切换
    var middleware = proxyMiddleware(['/access'], {target: "http://172.28.3.3:8080", changeOrigin: true});
    browserSync({
        server: {
            baseDir: './access',
            middleware: middleware,
            index: 'index.html'
        }
    });

    gulp.watch('access/scripts_map/**/*.js',['reload']);
    gulp.watch('access/scripts/lib/**/*.js',['reload']);
    gulp.watch('access/scripts/plugins/**/*.js',['reload']);
    gulp.watch('access/scripts/app/app.js',['reload']);
    gulp.watch('access/scripts/app/appApi.js',['reload']);
    gulp.watch('access/scripts/app/appController.js',['reload']);
    gulp.watch('access/scripts/app/appData.js',['reload']);
    gulp.watch('access/**/*.html',['reload']);
    gulp.watch('access/**/*.css',['reload']);
    gulp.watch('access/**/*.json',['reload']);
});
// 默认任务
gulp.task('default',['babel', 'browserSync']);

